# main.py
import cv2
import pyautogui
from hand_detector import HandDetector

cap = cv2.VideoCapture(0)
detector = HandDetector()
last_x, last_y = None, None
gesture_cooldown = 0

while True:
    success, frame = cap.read()
    frame = cv2.flip(frame, 1)
    finger = detector.get_hand_position(frame)

    if finger:
        x, y = finger

        if last_x and last_y and gesture_cooldown == 0:
            dx = x - last_x
            dy = y - last_y

            if abs(dx) > 50:
                if dx > 0:
                    print("RIGHT SWIPE →")
                    pyautogui.press('right')
                else:
                    print("LEFT SWIPE ←")
                    pyautogui.press('left')
                gesture_cooldown = 15

            elif dy < -60:
                print("UP SWIPE ↑ (Jump)")
                pyautogui.press('up')
                gesture_cooldown = 15

            elif dy > 60:
                print("DOWN SWIPE ↓ (Roll)")
                pyautogui.press('down')
                gesture_cooldown = 15

        last_x, last_y = x, y

    if gesture_cooldown > 0:
        gesture_cooldown -= 1

    cv2.imshow("Gesture Control", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

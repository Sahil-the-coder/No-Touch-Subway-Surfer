# test_hand.py (Optional for testing)

import cv2
from hand_detector import HandDetector

cap = cv2.VideoCapture(0)
detector = HandDetector()

while True:
    success, frame = cap.read()
    landmarks = detector.get_hand_position(frame)

    if landmarks:
        cv2.circle(frame, landmarks[8], 10, (255, 0, 0), -1)  # Draw dot on index finger

    cv2.imshow("Hand Tracking", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# game.py
import pygame

class Player:
    def __init__(self):
        self.lanes = [150, 275, 400]  # X positions for 3 lanes
        self.lane_index = 1
        self.x = self.lanes[self.lane_index]
        self.y = 500
        self.width = 50
        self.height = 50
        self.color = (0, 255, 0)
        self.jumping = False
        self.jump_height = 150
        self.jump_velocity = 0
        self.gravity = 5

    def move_left(self):
        if self.lane_index > 0:
            self.lane_index -= 1
            self.x = self.lanes[self.lane_index]

    def move_right(self):
        if self.lane_index < len(self.lanes) - 1:
            self.lane_index += 1
            self.x = self.lanes[self.lane_index]

    def jump(self):
        if not self.jumping:
            self.jumping = True
            self.jump_velocity = -20  # Upward velocity

    def update(self):
        if self.jumping:
            self.y += self.jump_velocity
            self.jump_velocity += self.gravity
            if self.y >= 500:
                self.y = 500
                self.jumping = False

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.width, self.height))
